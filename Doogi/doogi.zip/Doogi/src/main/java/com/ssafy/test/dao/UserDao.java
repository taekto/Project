package com.ssafy.test.dao;

import java.util.List;

import com.ssafy.test.dto.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserDao {
	public List<User> selectAll();
	public void insertUser(User user);
	public User selectOne(String id);
}